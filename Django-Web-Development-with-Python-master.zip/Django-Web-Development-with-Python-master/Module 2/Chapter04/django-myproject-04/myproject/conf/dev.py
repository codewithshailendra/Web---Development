# -*- coding: UTF-8 -*-
from base import *

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

DEBUG = True