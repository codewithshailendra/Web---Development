# -*- coding: UTF-8 -*-
from __future__ import unicode_literals
from .base import *

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
